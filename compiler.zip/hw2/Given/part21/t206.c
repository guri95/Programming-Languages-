int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_k
= -12345;
counter[0]=counter[0] + 1;
ex_count=1;
counter[1]=counter[1] + 1;
ex_count=2;
counter[2]=counter[2] + 1;
ex_count=3;
counter[3]=counter[3] + 1;
ex_count=4;
counter[4]=counter[4] + 1;
ex_count=5;
counter[5]=counter[5] + 1;
ex_count=6;
counter[6]=counter[6] + 1;
ex_count=7;
counter[7]=counter[7] + 1;
ex_count=8;
counter[8]=counter[8] + 1;
ex_count=9;
counter[9]=counter[9] + 1;
ex_count=10;
counter[10]=counter[10] + 1;
ex_count=11;
counter[11]=counter[11] + 1;
ex_count=12;
counter[12]=counter[12] + 1;
ex_count=13;
counter[13]=counter[13] + 1;
ex_count=14;
counter[14]=counter[14] + 1;
ex_count=15;
counter[15]=counter[15] + 1;
ex_count=16;
counter[16]=counter[16] + 1;
ex_count=17;
counter[17]=counter[17] + 1;
ex_count=18;
counter[18]=counter[18] + 1;
ex_count=19;
counter[19]=counter[19] + 1;
ex_count=20;
counter[20]=counter[20] + 1;
ex_count=21;
counter[21]=counter[21] + 1;
ex_count=22;
counter[22]=counter[22] + 1;
ex_count=23;
counter[23]=counter[23] + 1;
ex_count=24;
counter[24]=counter[24] + 1;
ex_count=25;
counter[25]=counter[25] + 1;
ex_count=26;
counter[26]=counter[26] + 1;
ex_count=27;
counter[27]=counter[27] + 1;
ex_count=28;
counter[28]=counter[28] + 1;
ex_count=29;
counter[29]=counter[29] + 1;
ex_count=30;
counter[30]=counter[30] + 1;
ex_count=31;
counter[31]=counter[31] + 1;
ex_count=32;
counter[32]=counter[32] + 1;
ex_count=33;
counter[33]=counter[33] + 1;
ex_count=34;
counter[34]=counter[34] + 1;
ex_count=35;
counter[35]=counter[35] + 1;
ex_count=36;
counter[36]=counter[36] + 1;
ex_count=37;
counter[37]=counter[37] + 1;
ex_count=38;
counter[38]=counter[38] + 1;
ex_count=39;
counter[39]=counter[39] + 1;
ex_count=40;
counter[40]=counter[40] + 1;
ex_count=41;
counter[41]=counter[41] + 1;
ex_count=42;
counter[42]=counter[42] + 1;
ex_count=43;
counter[43]=counter[43] + 1;
ex_count=44;
counter[44]=counter[44] + 1;
ex_count=45;
counter[45]=counter[45] + 1;
ex_count=46;
counter[46]=counter[46] + 1;
ex_count=47;
counter[47]=counter[47] + 1;
ex_count=48;
counter[48]=counter[48] + 1;
ex_count=49;
counter[49]=counter[49] + 1;
ex_count=50;
counter[50]=counter[50] + 1;
ex_count=51;
counter[51]=counter[51] + 1;
ex_count=52;
counter[52]=counter[52] + 1;
ex_count=53;
counter[53]=counter[53] + 1;
ex_count=54;
counter[54]=counter[54] + 1;
ex_count=55;
counter[55]=counter[55] + 1;
ex_count=56;
counter[56]=counter[56] + 1;
ex_count=57;
counter[57]=counter[57] + 1;
ex_count=58;
counter[58]=counter[58] + 1;
ex_count=59;
counter[59]=counter[59] + 1;
ex_count=60;
counter[60]=counter[60] + 1;
ex_count=61;
counter[61]=counter[61] + 1;
ex_count=62;
counter[62]=counter[62] + 1;
ex_count=63;
counter[63]=counter[63] + 1;
ex_count=64;
counter[64]=counter[64] + 1;
ex_count=65;
counter[65]=counter[65] + 1;
ex_count=66;
counter[66]=counter[66] + 1;
ex_count=67;
counter[67]=counter[67] + 1;
ex_count=68;
counter[68]=counter[68] + 1;
ex_count=69;
counter[69]=counter[69] + 1;
ex_count=70;
counter[70]=counter[70] + 1;
ex_count=71;
counter[71]=counter[71] + 1;
ex_count=72;
counter[72]=counter[72] + 1;
ex_count=73;
counter[73]=counter[73] + 1;
ex_count=74;
counter[74]=counter[74] + 1;
ex_count=75;
counter[75]=counter[75] + 1;
ex_count=76;
counter[76]=counter[76] + 1;
ex_count=77;
counter[77]=counter[77] + 1;
ex_count=78;
counter[78]=counter[78] + 1;
ex_count=79;
counter[79]=counter[79] + 1;
ex_count=80;
counter[80]=counter[80] + 1;
ex_count=81;
counter[81]=counter[81] + 1;
ex_count=82;
counter[82]=counter[82] + 1;
ex_count=83;
counter[83]=counter[83] + 1;
ex_count=84;
counter[84]=counter[84] + 1;
ex_count=85;
counter[85]=counter[85] + 1;
ex_count=86;
counter[86]=counter[86] + 1;
ex_count=87;
counter[87]=counter[87] + 1;
ex_count=88;
counter[88]=counter[88] + 1;
ex_count=89;
counter[89]=counter[89] + 1;
ex_count=90;
for(
x_k
=
1
;
x_k
<=
100
;
x_k
++)
{
{
counter[90]=counter[90] + 1;
ex_count=91;
counter[91]=counter[91] + 1;
ex_count=92;
counter[92]=counter[92] + 1;
ex_count=93;
counter[93]=counter[93] + 1;
ex_count=94;
counter[94]=counter[94] + 1;
ex_count=95;
counter[95]=counter[95] + 1;
ex_count=96;
counter[96]=counter[96] + 1;
ex_count=97;
counter[97]=counter[97] + 1;
ex_count=98;
counter[98]=counter[98] + 1;
ex_count=99;
counter[99]=counter[99] + 1;
ex_count=100;
}
}
label1:;
printf("%d\n", 
x_k
);
