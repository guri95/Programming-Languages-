int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_k
= -12345;
int
x_sume
= -12345;
int
x_sumo
= -12345;
counter[0]=counter[0] + 1;
ex_count=1;
x_sume
=
0
;
x_sumo
=
0
;
for(
x_k
=
1
;
x_k
<=
1000
;
x_k
++)
{
{
counter[1]=counter[1] + 1;
ex_count=2;
if(
mod
(
x_k
,
2
)
==
0
)
{
{
x_sume
=
x_sume
+
x_k
;
counter[2]=counter[2] + 1;
ex_count=3;
}
}
else
{
{
x_sumo
=
x_sumo
+
x_k
;
counter[3]=counter[3] + 1;
ex_count=4;
}
}
counter[4]=counter[4] + 1;
ex_count=5;
if(
mod
(
x_k
,
10
)
==
0
)
{
{
 printf("+++ dump on line 16 of all levels begin +++\n"); 
char getString_1_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,1,0,getString_1_k);
char getString_2_sume[]="sume";
 printf("%12d %3d %3d %s\n",x_sume,1,0,getString_2_sume);
char getString_3_sumo[]="sumo";
 printf("%12d %3d %3d %s\n",x_sumo,1,0,getString_3_sumo);
 printf("--- dump on line 16 of all levels end ---\n");
counter[5]=counter[5] + 1;
ex_count=6;
}
}
if(
x_k
>
9999
)
{
{
counter[6]=counter[6] + 1;
ex_count=7;
}
}
}
}
label1:;
counter[7]=counter[7] + 1;
ex_count=8;
}
setlineNum[0]=2;
setlineNum[1]=6;
setlineNum[2]=9;
setlineNum[3]=12;
setlineNum[4]=14;
setlineNum[5]=17;
setlineNum[6]=20;
setlineNum[7]=23;
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<8;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
