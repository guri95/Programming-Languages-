int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
printf("%d\n", 
11111
);
}
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<0;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
