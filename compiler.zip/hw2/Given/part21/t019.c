int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_state
= -12345;
int
x_ta
= -12345;
int
x_tb
= -12345;
int
x_tc
= -12345;
int
x_td
= -12345;
int
x_te
= -12345;
int
x_na
= -12345;
int
x_nb
= -12345;
int
x_nc
= -12345;
int
x_nd
= -12345;
int
x_ne
= -12345;
x_ta
=
3
;
x_na
=
4
;
x_tb
=
3
;
x_nb
=
1
;
x_tc
=
2
;
x_nc
=
5
;
x_td
=
1
;
x_nd
=
99
;
x_te
=
1
;
x_ne
=
2
;
x_state
=
3
;
while(1){
if(
x_state
==
1
)
{
{
printf("%d\n", 
100
+
x_state
);
x_ta
=
x_ta
-
1
;
if(
x_ta
==
0
)
{
{
x_state
=
x_na
;
}
}
}
}
else
if(
x_state
==
2
)
{
{
printf("%d\n", 
200
+
x_state
);
x_tb
=
x_tb
-
1
;
if(
x_tb
==
0
)
{
{
x_state
=
x_nb
;
}
}
}
}
else
if(
x_state
==
3
)
{
{
printf("%d\n", 
300
+
x_state
);
x_tc
=
x_tc
-
1
;
if(
x_tc
==
0
)
{
{
x_state
=
x_nc
;
}
}
}
}
else
if(
x_state
==
4
)
{
{
printf("%d\n", 
400
+
x_state
);
x_td
=
x_td
-
1
;
if(
x_td
==
0
)
{
{
x_state
=
x_nd
;
}
}
}
}
else
if(
x_state
==
5
)
{
{
printf("%d\n", 
500
+
x_state
);
x_te
=
x_te
-
1
;
if(
x_te
==
0
)
{
{
x_state
=
x_ne
;
}
}
}
}
else break;
}
label1:;
printf("%d\n", 
x_state
);
}
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<0;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
