int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_repeat
= -12345;
int
x_bigSum
= -12345;
x_bigSum
=
0
;
for(
x_repeat
=
1
;
x_repeat
<=
2
;
x_repeat
++)
{
{
int
x_k
= -12345;
int
x_sum
= -12345;
x_sum
=
0
;
 printf("+++ dump on line 11 of level 0 begin +++\n"); 
char getString_1_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_1_repeat);
char getString_2_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_2_bigSum);
 printf("--- dump on line 11 of level 0 end ---\n");
 printf("+++ dump on line 12 of level 1 begin +++\n"); 
char getString_3_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,8,1,getString_3_k);
char getString_4_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,8,1,getString_4_sum);
 printf("--- dump on line 12 of level 1 end ---\n");
for(
x_k
=
1
;
x_k
<=
10
;
x_k
++)
{
{
x_sum
=
x_sum
+
x_k
;
 printf("+++ dump on line 15 of level 0 begin +++\n"); 
char getString_5_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_5_repeat);
char getString_6_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_6_bigSum);
 printf("--- dump on line 15 of level 0 end ---\n");
 printf("+++ dump on line 16 of level 1 begin +++\n"); 
char getString_7_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,8,1,getString_7_k);
char getString_8_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,8,1,getString_8_sum);
 printf("--- dump on line 16 of level 1 end ---\n");
}
}
label2:;
x_bigSum
=
x_bigSum
+
x_sum
;
}
}
label1:;
}
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<0;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
