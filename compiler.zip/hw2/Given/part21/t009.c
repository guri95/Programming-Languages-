int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_i
= -12345;
int
x_k
= -12345;
int
x_long
= -12345;
int
x_n
= -12345;
x_i
=
25
;
while(1){
if(
10
!=
x_i
)
{
{
if(
20
==
x_i
)
{
{
x_k
=
20
-
x_i
;
while(1){
if(
x_k
)
{
{
printf("%d\n", 
x_k
);
x_k
=
x_k
+
1
;
}
}
else break;
}
label2:;
}
}
else
if(
15
==
x_i
)
{
{
x_k
=
15
-
x_i
;
x_n
=
5
;
while(1){
if(
x_k
)
{
{
x_long
=
10
*
x_k
;
printf("%d\n", 
x_long
);
x_k
=
x_k
+
1
;
}
}
else
if(
x_n
)
{
{
printf("%d\n", 
x_n
);
x_n
=
0
;
}
}
else break;
}
label3:;
printf("%d\n", 
x_long
);
}
}
else
{
{
x_k
=
10
-
x_i
;
while(1){
if(
x_k
)
{
{
printf("%d\n", 
x_k
);
x_k
=
x_k
+
1
;
}
}
else break;
}
label4:;
}
}
x_i
=
x_i
-
1
;
}
}
else break;
}
label1:;
printf("%d\n", 
x_i
);
}
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<0;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
