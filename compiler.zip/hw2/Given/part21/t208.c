int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_x
= -12345;
int
x_y
= -12345;
x_x
=
2
;
while(1){
if(
x_x
<
1000
)
{
{
counter[0]=counter[0] + 1;
ex_count=1;
x_y
=
3
;
while(1){
if(
x_y
<
400
)
{
{
counter[1]=counter[1] + 1;
ex_count=2;
if(
x_x
+
x_y
>
444
)
{
{
counter[2]=counter[2] + 1;
ex_count=3;
printf("%d\n", 
x_x
);
printf("%d\n", 
x_y
);
 printf("+++ dump on line 12 of all levels begin +++\n"); 
char getString_1_x[]="x";
 printf("%12d %3d %3d %s\n",x_x,1,0,getString_1_x);
char getString_2_y[]="y";
 printf("%12d %3d %3d %s\n",x_y,1,0,getString_2_y);
 printf("--- dump on line 12 of all levels end ---\n");
setlineNum[0]=5;
setlineNum[1]=8;
setlineNum[2]=10;
print();
exit(0);
}
}
counter[3]=counter[3] + 1;
ex_count=4;
x_y
=
x_y
+
3
;
}
}
else break;
}
label2:;
counter[4]=counter[4] + 1;
ex_count=5;
x_x
=
x_x
+
2
;
}
}
else break;
}
label1:;
counter[5]=counter[5] + 1;
ex_count=6;
 printf("+++ dump on line 22 of all levels begin +++\n"); 
char getString_3_x[]="x";
 printf("%12d %3d %3d %s\n",x_x,1,0,getString_3_x);
char getString_4_y[]="y";
 printf("%12d %3d %3d %s\n",x_y,1,0,getString_4_y);
 printf("--- dump on line 22 of all levels end ---\n");
}
setlineNum[0]=5;
setlineNum[1]=8;
setlineNum[2]=10;
setlineNum[3]=15;
setlineNum[4]=18;
setlineNum[5]=21;
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<6;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
