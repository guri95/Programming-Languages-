int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int counter[100]={0};
int setlineNum[100]={0};
int ex_count=0;
void print();
int main() {
{
int
x_a
= -12345;
int
x_b
= -12345;
int
x_c
= -12345;
 printf("+++ dump on line 2 of all levels begin +++\n"); 
char getString_1_a[]="a";
 printf("%12d %3d %3d %s\n",x_a,1,0,getString_1_a);
char getString_2_b[]="b";
 printf("%12d %3d %3d %s\n",x_b,1,0,getString_2_b);
char getString_3_c[]="c";
 printf("%12d %3d %3d %s\n",x_c,1,0,getString_3_c);
 printf("--- dump on line 2 of all levels end ---\n");
x_a
=
10
;
x_b
=
20
;
 printf("+++ dump on line 5 of all levels begin +++\n"); 
char getString_4_a[]="a";
 printf("%12d %3d %3d %s\n",x_a,1,0,getString_4_a);
char getString_5_b[]="b";
 printf("%12d %3d %3d %s\n",x_b,1,0,getString_5_b);
char getString_6_c[]="c";
 printf("%12d %3d %3d %s\n",x_c,1,0,getString_6_c);
 printf("--- dump on line 5 of all levels end ---\n");
x_a
=
x_b
;
x_c
=
44
;
 printf("+++ dump on line 8 of all levels begin +++\n"); 
char getString_7_a[]="a";
 printf("%12d %3d %3d %s\n",x_a,1,0,getString_7_a);
char getString_8_b[]="b";
 printf("%12d %3d %3d %s\n",x_b,1,0,getString_8_b);
char getString_9_c[]="c";
 printf("%12d %3d %3d %s\n",x_c,1,0,getString_9_c);
 printf("--- dump on line 8 of all levels end ---\n");
 printf("+++ dump on line 9 of all levels begin +++\n"); 
char getString_10_a[]="a";
 printf("%12d %3d %3d %s\n",x_a,1,0,getString_10_a);
char getString_11_b[]="b";
 printf("%12d %3d %3d %s\n",x_b,1,0,getString_11_b);
char getString_12_c[]="c";
 printf("%12d %3d %3d %s\n",x_c,1,0,getString_12_c);
 printf("--- dump on line 9 of all levels end ---\n");
}
print();
return 0; }
void print(){ if(ex_count>0){ printf("---- Execution Counts ----\n"); 	 printf(" num line    count\n");	}	  for(int i=0;i<0;i++){ 	printf("%4d %4d %8d\n",i+1, setlineNum[i],counter[i]);   }	 }
