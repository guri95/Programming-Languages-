int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int main() {
{
int
x_repeat
= -12345;
int
x_bigSum
= -12345;
x_bigSum
=
0
;
for(
x_repeat
=
1
;
x_repeat
<=
2
;
x_repeat
++)
{
{
int
x_k
= -12345;
int
x_g
= -12345;
int
x_sum
= -12345;
x_sum
=
0
;
 printf("+++ dump of all levels begin +++\n"); 
char getString_1_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_1_repeat);
char getString_2_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_2_bigSum);
char getString_3_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,7,1,getString_3_k);
char getString_4_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,7,1,getString_4_g);
char getString_5_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,7,1,getString_5_sum);
 printf("--- dump of all levels end ---\n");
for(
x_k
=
1
;
x_k
<=
10
;
x_k
++)
{
{
x_sum
=
x_sum
+
x_k
;
 printf("+++ dump of all levels begin +++\n"); 
char getString_6_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_6_repeat);
char getString_7_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_7_bigSum);
char getString_8_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,7,1,getString_8_k);
char getString_9_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,7,1,getString_9_g);
char getString_10_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,7,1,getString_10_sum);
 printf("--- dump of all levels end ---\n");
}
}
label2:;
for(
x_g
=
1
;
x_g
<=
10
;
x_g
++)
{
{
x_sum
=
x_sum
+
x_g
;
 printf("+++ dump of all levels begin +++\n"); 
char getString_11_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_11_repeat);
char getString_12_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_12_bigSum);
char getString_13_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,7,1,getString_13_k);
char getString_14_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,7,1,getString_14_g);
char getString_15_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,7,1,getString_15_sum);
 printf("--- dump of all levels end ---\n");
}
}
label3:;
x_bigSum
=
x_bigSum
+
x_sum
;
}
}
label1:;
 printf("+++ dump of all levels begin +++\n"); 
char getString_16_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_16_repeat);
char getString_17_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_17_bigSum);
 printf("--- dump of all levels end ---\n");
}
return 0; }
