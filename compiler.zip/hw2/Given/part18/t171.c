int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int main() {
{
int
x_k
= -12345;
int
x_j
= -12345;
int
x_i
= -12345;
int
x_sum
= -12345;
for(
x_j
=
1
;
x_j
<=
3
;
x_j
++)
{
{
x_sum
=
0
;
for(
x_k
=
1
;
x_k
<=
20
;
x_k
++)
{
{
x_sum
=
x_sum
+
x_k
;
if(
x_sum
>
30
)
{
{
printf("%d\n", 
888
);
for(
x_i
=
78
;
x_i
<=
79
;
x_i
++)
{
{
printf("%d\n", 
x_i
);
}
}
label3:;
goto label2;
}
}
printf("%d\n", 
x_k
);
}
}
label2:;
printf("%d\n", 
x_sum
);
for(
x_k
=
1
;
x_k
<=
20
;
x_k
++)
{
{
if(
x_k
==
9
)
{
{
goto label4;
}
}
}
}
label4:;
printf("%d\n", 
x_k
);
if(
x_j
>
1
)
{
{
if(
x_sum
>
30
)
{
{
goto label1;
}
}
}
}
}
}
label1:;
printf("%d\n", 
x_j
);
printf("%d\n", 
7654321
);
}
return 0; }
