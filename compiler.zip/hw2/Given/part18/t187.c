int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int main() {
{
int
x_repeat
= -12345;
int
x_bigSum
= -12345;
int
x_once
= -12345;
int
x_einmal
= -12345;
x_bigSum
=
0
;
for(
x_repeat
=
1
;
x_repeat
<=
2
;
x_repeat
++)
{
{
int
x_g
= -12345;
int
x_sum
= -12345;
x_sum
=
0
;
for(
x_once
=
1
;
x_once
<=
1
;
x_once
++)
{
{
 printf("+++ dump of all levels begin +++\n"); 
char getString_1_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_1_repeat);
char getString_2_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_2_bigSum);
char getString_3_once[]="once";
 printf("%12d %3d %3d %s\n",x_once,1,0,getString_3_once);
char getString_4_einmal[]="einmal";
 printf("%12d %3d %3d %s\n",x_einmal,1,0,getString_4_einmal);
char getString_5_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,6,1,getString_5_g);
char getString_6_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,6,1,getString_6_sum);
 printf("--- dump of all levels end ---\n");
for(
x_einmal
=
1
;
x_einmal
<=
1
;
x_einmal
++)
{
{
int
x_k
= -12345;
for(
x_k
=
1
;
x_k
<=
2
;
x_k
++)
{
{
printf("%d\n", 
x_repeat
);
printf("%d\n", 
x_k
);
 printf("+++ dump of all levels begin +++\n"); 
char getString_7_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_7_repeat);
char getString_8_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_8_bigSum);
char getString_9_once[]="once";
 printf("%12d %3d %3d %s\n",x_once,1,0,getString_9_once);
char getString_10_einmal[]="einmal";
 printf("%12d %3d %3d %s\n",x_einmal,1,0,getString_10_einmal);
char getString_11_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,6,1,getString_11_g);
char getString_12_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,6,1,getString_12_sum);
char getString_13_k[]="k";
 printf("%12d %3d %3d %s\n",x_k,12,3,getString_13_k);
 printf("--- dump of all levels end ---\n");
}
}
label4:;
}
}
label3:;
}
}
label2:;
for(
x_g
=
1
;
x_g
<=
10
;
x_g
++)
{
{
x_sum
=
x_sum
+
x_g
;
 printf("+++ dump of all levels begin +++\n"); 
char getString_14_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_14_repeat);
char getString_15_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_15_bigSum);
char getString_16_once[]="once";
 printf("%12d %3d %3d %s\n",x_once,1,0,getString_16_once);
char getString_17_einmal[]="einmal";
 printf("%12d %3d %3d %s\n",x_einmal,1,0,getString_17_einmal);
char getString_18_g[]="g";
 printf("%12d %3d %3d %s\n",x_g,6,1,getString_18_g);
char getString_19_sum[]="sum";
 printf("%12d %3d %3d %s\n",x_sum,6,1,getString_19_sum);
 printf("--- dump of all levels end ---\n");
}
}
label5:;
x_bigSum
=
x_bigSum
+
x_sum
;
}
}
label1:;
 printf("+++ dump of all levels begin +++\n"); 
char getString_20_repeat[]="repeat";
 printf("%12d %3d %3d %s\n",x_repeat,1,0,getString_20_repeat);
char getString_21_bigSum[]="bigSum";
 printf("%12d %3d %3d %s\n",x_bigSum,1,0,getString_21_bigSum);
char getString_22_once[]="once";
 printf("%12d %3d %3d %s\n",x_once,1,0,getString_22_once);
char getString_23_einmal[]="einmal";
 printf("%12d %3d %3d %s\n",x_einmal,1,0,getString_23_einmal);
 printf("--- dump of all levels end ---\n");
}
return 0; }
