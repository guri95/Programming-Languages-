int esquare(int x){ return x*x;}
#include <math.h>
#include <string.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x, int y) {int z = 0; int temp = 0; if (y == 0) {printf("\nmod(a,b) with b=0\n"); exit(1);} if (x == 0) {z = 0;} if (x > 0 && y > 0) {z = x; while (z - y >= 0) {z = z - y;}} else if (x < 0 && y < 0) {z = x; while (z - y <= 0) {z = z-y;}} else if (x < 0 && y > 0) {temp = x; while (temp < y && temp < 0) {temp = temp + y; z = temp;}} else if (x > 0 && y < 0) {temp = x; while (temp > y && temp > 0) {temp = temp + y; z = temp;}} return z;}
#define max(a,b) ((a>b)?a:b)
int main() {
{
int
x_a
= -12345;
int
x_b
= -12345;
int
x_c
= -12345;
int
x_d
= -12345;
for(
x_a
=
1
;
x_a
<=
2
;
x_a
++)
{
{
}
}
label1:;
x_a
=
0
;
for(
x_b
=
1
;
x_b
<=
3
;
x_b
++)
{
{
int
x_x
= -12345;
for(
x_x
=
5
;
x_x
<=
6
;
x_x
++)
{
{
printf("%d\n", 
x_x
);
x_a
=
