int esquare(int x){ return x*x;}
#include <math.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x,int y){ int z=0; int temp=0; if (x == y) {z = 0;}  if (x >= 0 ) { temp = x; while(temp >= y) {temp = temp-y; z = temp;} if(x<y){z=x;}}  if (x < 0 ) { temp = x; while(temp < y && temp < 0) {temp = temp+y; z = temp;}}   return z;}
int main() {
{
int
x_k
= -12345;
int
x_n
= -12345;
for(
x_k
=
5
;
x_k
<=
1
;
x_k
++)
if( 
x_k
!=
3
)
{
{
printf("%d\n", 
x_k
);
}
}
printf("%d\n", 
x_k
);
x_n
=
0
;
for(
x_k
=
1
;
x_k
<=
5
;
x_k
++)
{
{
if(
x_k
!=
3
)
{
{
x_n
=
x_n
+
1
;
printf("%d\n", 
x_k
);
}
}
else
{
{
printf("%d\n", 
8888
);
exit(0);
}
}
}
}
printf("%d\n", 
x_n
);
}
return 0; }
