int esquare(int x){ return x*x;}
#include <math.h>
int esqrt(int x){ double y; if (x < 0) return 0; y = sqrt((double)x); return (int)y;}
#include <stdlib.h>
#include <stdio.h>
int mod(int x,int y){ int z=0; int temp=0; if (x == y) {z = 0;}  if (x >= 0 ) { temp = x; while(temp >= y) {temp = temp-y; z = temp;} if(x<y){z=x;}}  if (x < 0 ) { temp = x; while(temp < y && temp < 0) {temp = temp+y; z = temp;}}   return z;}
int main() {
{
int
x_a
= -12345;
int
x_b
= -12345;
int
x_c
= -12345;
int
x_d
= -12345;
for(
x_a
=
1
;
x_a
<=
2
;
x_a
++)
{
{
}
}
x_a
=
0
;
for(
x_b
=
1
;
x_b
<=
3
;
x_b
++)
{
{
int
x_x
= -12345;
for(
x_x
=
5
;
x_x
<=
6
;
x_x
++)
{
{
printf("%d\n", 
x_x
);
x_a
=
x_a
+
x_x
;
}
}
}
}
printf("%d\n", 
