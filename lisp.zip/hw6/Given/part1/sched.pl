% Part 1: Simple Queries -----------------------------------------------------------------------

/*names of all national parks*/
np_names(N) :-
	np(N,_,_).

/*names of all national parks other than yosemite*/
np_names_not_yosemite(N) :-
	np(N,_,_),
	N\=yosemite.

/*list of activities available at yosemite*/
np_activities_yosemite(A) :-
	np(N,_,A),
	N=yosemite.

/*list of states for yosemite*/
np_states_yosemite(S) :-
	np(N,S,_),
	N=yosemite.

/*list of states for grandcanyon*/
np_states_grandcanyon(S) :-
	np(N,S,_),
	N=grandcanyon.

/*list of states for national park with name N*/
np_states(N, S) :-
	np(N,S,_).

/*sorted list of activities at yosemite*/
np_sorted_activities_yosemite(SA) :-
	np(N,_,A),
	N=yosemite,
	sort(A, SA).

/*names of parks that are within exactly one state*/
np_single_state(N) :-
	np(N,S,_),
	length(S,1).

/*names of parks that are within two or more states*/
np_multi_state(N) :-
	np(N,S,_),
	length(S,Z),
	Z>1.

/*ordered pairs (each as a list of 2) of names of 2 (different) parks that are within exactly one state that is the same*/
np_pair_names([N1, N2]) :-
	np(N1,S,_),
	np(N2,S,_),
	N1@<N2.

/*names of parks that are within exactly two states and offer exactly two activities*/
np_2_state_2_activities(N) :-
	np(N,S,A),
	length(S,2),
	length(A,2).

/*names of parks that are within exactly one or exactly two states*/
/*1st way using or operator....*/
np_12_states_1or(N) :-
	np(N,S,_),
	length(S,1);
	np(N,S,_),
	length(S,2).

/*2nd way without using or operator....*/
np_12_states_2wo(N) :-
	np(N,S,_),
	length(S,Z),
	Z>0,
	Z<3.


/*names of parks that provide exactly camping and hiking (in either order)*/
/*1st way using or, using 1 rule*/
np_camping_hiking_1or(N) :-
	np(N,_,A),
	A=[camping, hiking];
	np(N,_,A),
	A=[hiking, camping].


/*2nd way without or, using 2 rules*/
np_camping_hiking_2wo(N) :-
	np(N,_,A),
	A=[camping, hiking].

np_camping_hiking_2wo(N) :-
	np(N,_,A),
	A=[hiking, camping].


/*3rd way, using sort*/
np_camping_hiking_sort(N) :-
	np(N,_,A),
	A=[camping, hiking],
	sort(A, SA);

	np(N,_,A),
	A=[hiking, camping],
	sort(A, SA).


