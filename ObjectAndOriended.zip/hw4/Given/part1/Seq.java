// the Seq base class

public abstract class Seq {
	
	
}


