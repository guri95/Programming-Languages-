import java.util.*;
import java.lang.*;

public class AList {

	ArrayList<Object> AL = new ArrayList<Object>();

	//overwriting Objects toString method 
	public String toString(){
		String stringAL = AL.toString()
				.replace(",", "")
				.replaceFirst("\\[", "\\[ ")
				.trim();
		for (int i = stringAL.length(); i > 0; i--) {
			stringAL.replaceFirst("\\]", "\\ ]");
			break;
		}
				
		return String.format(""+stringAL+""); 

	}

	public void add (Seq s) {
		AL.add(s);
	
	}

	public void add (AList a) {
		AL.add(a);
	}

	public void add (int i) {
		Integer intObj = new Integer(i);
		AL.add(intObj);
	}


}
