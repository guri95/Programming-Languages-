public interface EF{

	// expand AList
	public AList expandme();
	
	// flatten AList
	public AList flattenme();
}
