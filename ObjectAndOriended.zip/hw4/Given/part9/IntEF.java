public class IntEF implements EF{

	public int expandme()
	{
		//AList expand_obj = new AList(); //creating new AList specifically for expand()
		//AList expand_ret = new AList(); //acts as temp holder for recursing expand()

		return ((int)AL.get(i));

		//return expand_obj;
	}


	public int flattenme()
	{
		return ((int)AL.get(i));
	}

}
