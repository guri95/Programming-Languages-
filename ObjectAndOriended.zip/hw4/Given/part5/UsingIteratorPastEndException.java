//part5
public class UsingIteratorPastEndException extends Exception {

	static final long serialVersionUID = 98L; 

	public UsingIteratorPastEndException(String msg) {
		super(msg);
	}

}
