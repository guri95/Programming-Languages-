public class ForIt implements SeqIt{
	
	protected For f;
	protected int count;
	
	public ForIt(For forObj)
	{
		f = forObj;
		count = 0;
	}	

	public boolean hasNext(){

		//if current value + step is less than last, then there is a next value
		int current = f.forF + (f.forS * count);
		if (f.forS >=0 && current<= f.forL){ 
			return true;
		}
		if (f.forS <0 && current >= f.forL){ 
			return true;
		}
		return false;
	}

	public int next() throws UsingIteratorPastEndException{
		if (!hasNext()){
			
	
			//part5
			throw new UsingIteratorPastEndException("");
		}

		//add step*(# of iterations) to the initial value to get the next value
		return f.forF + (f.forS * count++);
	}

}
