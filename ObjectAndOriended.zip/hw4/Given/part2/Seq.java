// the Seq base class

public abstract class Seq {
	
	//part 2
	public abstract int upperBound();
}


